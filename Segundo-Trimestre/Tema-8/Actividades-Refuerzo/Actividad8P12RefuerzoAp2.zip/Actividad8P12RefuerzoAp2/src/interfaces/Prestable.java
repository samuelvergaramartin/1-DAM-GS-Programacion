package interfaces;

public interface Prestable {
    void presta();
    void devuelve();
    boolean estaPrestado();
}
