public class Main {
    public static void main(String[] args) {
        Tiempo t = new Tiempo(1, 23, 17),t2;

        //System.out.println(t);

        t.resta(new Tiempo(0, 45, 8));

        //System.out.println(t);

        //t2 = new Tiempo(0, 45, 8);

        //t2.suma(new Tiempo(0, 22, 9));

        //System.out.println(t2);
    }
}