public class Main {
    public static void main(String[] args) {
        String resultado;
        FichaDomino f1, f2;

        for(int i = 0; i < 8; i++) {
            
        }
    }
}