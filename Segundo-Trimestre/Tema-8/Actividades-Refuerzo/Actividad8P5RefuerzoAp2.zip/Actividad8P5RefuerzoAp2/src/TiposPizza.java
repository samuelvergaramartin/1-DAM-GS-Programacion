public enum TiposPizza {
    MARGARITA, CUATROQUESOS, FUNGHI
}
