public class Main {
    public static void main(String[] args) {
        Caballo c = new Caballo("Pepe", 12, "Vaquero");

        System.out.println(c);
    }
}