package maritimo;

public class MotoAcuatica {

}
