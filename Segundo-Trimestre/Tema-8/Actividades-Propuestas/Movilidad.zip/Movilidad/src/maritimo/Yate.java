package maritimo;

public class Yate {
    
}
