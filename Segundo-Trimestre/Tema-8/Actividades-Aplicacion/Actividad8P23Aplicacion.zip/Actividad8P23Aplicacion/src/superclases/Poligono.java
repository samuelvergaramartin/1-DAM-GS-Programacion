package superclases;

public abstract class Poligono {
    protected double base, altura;

    public abstract double area();
}
