package enumerados;

public enum Unidad {
    M, CM
}
