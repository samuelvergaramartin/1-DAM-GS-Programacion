public class Main {
    public static void main(String[] args) {
        Hora hora = new Hora(10, 4);

        System.out.println(hora);
        hora.inc();
        System.out.println(hora);

        hora.setHora(23);
        hora.setMinutos(59);

        System.out.println(hora);
        hora.inc();
        System.out.println(hora);

        hora.setHora(10);
        hora.setMinutos(59);

        System.out.println(hora);
        hora.inc();

        System.out.println(hora);


    }
}