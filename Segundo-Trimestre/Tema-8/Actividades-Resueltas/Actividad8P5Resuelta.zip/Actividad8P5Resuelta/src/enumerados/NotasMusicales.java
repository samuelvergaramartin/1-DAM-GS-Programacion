package enumerados;

public enum NotasMusicales {
    DO, RE, MI, FA, SOL, LA, SI
}
