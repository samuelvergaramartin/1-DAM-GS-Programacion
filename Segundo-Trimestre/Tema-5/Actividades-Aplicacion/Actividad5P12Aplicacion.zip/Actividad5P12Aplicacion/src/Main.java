import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int numeros[] = new int[5];
        Scanner sc = new Scanner(System.in);

        for(int i = 0; i < numeros.length; i++) {
            System.out.print("Introduce un número: ");
            numeros[i] = sc.nextInt();
        }

        desordenar(numeros);

        System.out.println(java.util.Arrays.toString(numeros));
    }

    private static void desordenar(int tabla[]) {
        int aux[] = new int[tabla.length], contador = 0, posicion;
        boolean pos[] = new boolean[aux.length];

        for(int i = 0; i < tabla.length; i++) {
            aux[i] = tabla[i];
            tabla[i] = 0;
        }

        posicion = (int) (Math.random() * aux.length);

        tabla[posicion] = aux[0];
        pos[posicion] = true;
        contador++;

        while (contador < aux.length) {
            posicion = (int) (Math.random() * aux.length);

            if(!pos[posicion]) {
                tabla[posicion] = aux[contador];
                pos[posicion] = true;
                contador++;
            }
        }

        aux = null;
        pos = null;
    }
}