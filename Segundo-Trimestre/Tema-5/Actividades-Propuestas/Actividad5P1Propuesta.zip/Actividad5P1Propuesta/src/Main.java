public class Main {
    public static void main(String[] args) {
        int enteros[] = new int[5];
        double reales[] = new double[5];
        boolean booleanos[] = new boolean[5];

        System.out.println(enteros);
        System.out.println(reales);
        System.out.println(booleanos);
    }
}