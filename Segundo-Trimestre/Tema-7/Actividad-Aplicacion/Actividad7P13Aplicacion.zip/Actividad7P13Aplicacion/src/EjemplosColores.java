public enum EjemplosColores {
    Rojo, Azul, Amarillo, Verde, Marron, Naranja, Morado, Negro, Blanco, Gris
}
