package personal;

public enum EspecialidadesMecanicos {
    FRENOS, HIDRAULICA, ELECTRICIDAD, MOTOR
}
