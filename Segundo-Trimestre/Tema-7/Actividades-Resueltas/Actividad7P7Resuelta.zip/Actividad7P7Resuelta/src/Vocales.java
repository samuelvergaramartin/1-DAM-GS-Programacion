public enum Vocales {
    A, E, I, O, U, Á, É, Í, Ó, Ú
}
