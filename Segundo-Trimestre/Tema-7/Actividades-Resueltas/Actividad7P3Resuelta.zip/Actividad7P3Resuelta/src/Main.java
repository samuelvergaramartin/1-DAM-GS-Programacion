public class Main {
    public static void main(String[] args) {
        CuentaCorriente c = new CuentaCorriente("77426564P", "Samuel", 80);

        c.mostrarInformacion();


    }
}