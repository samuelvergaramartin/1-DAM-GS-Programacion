/**
 * @author Samuel Vergara Martín
 */
public class ActividadRefuerzo3 {
    public static void main(String[] args) {
        int multiplo5 = 0;
        do {
            System.out.println(multiplo5);
            multiplo5+=5;
        } while(multiplo5 < 105);
    }
}
