/**
 * @author Samuel Vergara Martín
 */
public class EjercicioTablaMultiplicar7 {
    public static void main(String[] args) {
        for(int i = 0; i <= 10; i++) {
            System.out.println(7 +  " X " + i + " = " + 7 * i);
        }
    }
}
