package ejemplo.pkg1;

/**
 *
 * @author Usuario
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        boolean verdadero = true;
        char c = '1';
        
        System.out.println("Caracter " + c);
    }
    
}
