/**
 * @author Samuel Vergara Martín
 */
import java.util.*;
public class Actividad5P9 {
    public static void main(String[] args) {
        int inputValue, extraLength, base = 5;
        int puntuaciones[] = new int[base];
        int extra[];
        Scanner sc = new Scanner(System.in);

        extraLength = base;

        do {
           System.out.print("Introduce una puntuacion");
        }
    }
}
