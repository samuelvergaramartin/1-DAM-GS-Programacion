/**
 * @author Samuel Vergara Martin
 * @see - 4 - Ejercicio 2.12 de las actividades de aplicacion del tema 2.
 */
import java.util.Scanner;
public class EjerciciioDictado4 {
    public static void main(String[] args) {
        int num;
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce su numero de DNI: ");
        num = sc.nextInt();

        letras = {};
    }
}
