/**
 * @author Samuel Vergara Martín
 */
import java.util.*;
public class ActividadPropuesta5P7 {
    public static void main(String[] args) {
        int numerosFavoritos[];
        int inputValue,numBorrar1,numBorrar2;
        Scanner sc = new Scanner(System.in);
    }
}
