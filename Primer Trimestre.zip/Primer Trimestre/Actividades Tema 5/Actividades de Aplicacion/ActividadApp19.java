/**
 * @author Samuel Vergara Martín
 */
import java.util.Scanner;
import java.util.Arrays;
public class ActividadApp19 {
    public static void main(String[] args) {
        
    }
}
