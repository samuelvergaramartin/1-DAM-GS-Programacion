/**
 * @author Samuel Vergara Martín
 */
public class ActividadRefuerzo2 {
    public static void main(String[] args) {
        char simbolos[];
        simbolos = new char[9];

        simbolos[0] = 'a';
        simbolos[1] = 'x';
        simbolos[4] = '@';
        simbolos[6] = ' ';
        simbolos[7] = '+';
        simbolos[8] = 'Q';

        
    }
}
