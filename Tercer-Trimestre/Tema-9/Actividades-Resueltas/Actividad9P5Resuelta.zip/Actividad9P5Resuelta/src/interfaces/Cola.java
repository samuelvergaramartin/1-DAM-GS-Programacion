package interfaces;

public interface Cola {
    void encolar(Integer elemento);
    Integer desencolar();
    Integer cima();
}
