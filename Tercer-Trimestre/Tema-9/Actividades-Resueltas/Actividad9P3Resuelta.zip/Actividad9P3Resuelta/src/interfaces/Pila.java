package interfaces;

public interface Pila {
    void apilar(Integer elemento);
    Integer desencolar();
    Integer cima();
}
