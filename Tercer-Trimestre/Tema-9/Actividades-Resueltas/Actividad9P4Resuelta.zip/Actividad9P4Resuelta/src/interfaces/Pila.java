package interfaces;

public interface Pila {
    void apilar(Integer elemento);
    Integer desapilar();
    Integer cima();
}
