package interfaces;

public interface Pila {
    void apilar(String elemento);
    String desapilar();
    String cima();
}
