package interfaces;

public interface Pila {
    void apilar(Object elemento);
    Object desapilar();
    Object cima();
}
