import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Contenedor<Integer> pila = new Contenedor<>(new Integer[0]);
        Scanner sc = new Scanner(System.in);
        int num;

        System.out.print("Introduzca un número: ");
        num = sc.nextInt();

        while (num != -1) {
            pila.apilar(num);
            System.out.print("Introduzca un número: ");
            num = sc.nextInt();
        }

        System.out.println("Desapilando...");

        while (pila.cima() != null) {
            System.out.println(pila.desapilar());
        }
    }
}