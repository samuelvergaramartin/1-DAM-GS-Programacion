public class Main {
    public static void main(String[] args) {
        int i = 320;

        do {
            System.out.println(i);
            i-=20;
        }
        while (i >= 160);
    }
}