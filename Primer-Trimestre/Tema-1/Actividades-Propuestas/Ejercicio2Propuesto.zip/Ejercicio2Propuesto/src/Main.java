public class Main {
    public static void main(String[] args) {
        System.out.println("Estoy probando la salida en consola");
        System.out.println("Ahora voy \n a escribir en distintas lineas \n utilizando una sola sentencia");
        System.out.println("Vamos a probar a tabular texto usanto \\t \t Texto tabulado");
        System.out.print(" Si quiero escribir lineas seguidas uso print en lugar de println");
    }
}