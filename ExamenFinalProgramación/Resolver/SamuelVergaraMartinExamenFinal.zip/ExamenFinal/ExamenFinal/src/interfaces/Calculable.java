package interfaces;

public interface Calculable {
    double calculoNota(double notaInicial);
}
