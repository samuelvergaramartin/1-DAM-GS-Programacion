package submarino;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Submarino {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        private final String cabeceraCodigo = "Sub-";
    }
    
}
