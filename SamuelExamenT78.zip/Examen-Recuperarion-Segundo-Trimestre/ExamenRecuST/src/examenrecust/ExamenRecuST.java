package examenrecust;

/**
 *
 * @author Samuel Vergara Martin
 */
public class ExamenRecuST {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
