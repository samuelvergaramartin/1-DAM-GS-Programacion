package ejercicio7p10;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Maquinista {
    String nombre;
    String dni;
    double sueldo;
    String rango;
    
    Maquinista(String nombre, String dni, double sueldo, String rango) {
        this.nombre = nombre;
        this.dni = dni;
        this.sueldo = sueldo;
        this.rango = rango;
    }
}
