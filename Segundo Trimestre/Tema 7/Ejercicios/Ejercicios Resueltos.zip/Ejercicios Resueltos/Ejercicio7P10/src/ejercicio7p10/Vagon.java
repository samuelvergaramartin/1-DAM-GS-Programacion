package ejercicio7p10;

/**
 *
 * @author Samuel Vergara Martín
 */
class Vagon {
    int numVagon;
    double cargaMaxima;
    double cargaActual;
    String tipoMercancia;
    
    Vagon(int numVagon, double cargaMaxima, double cargaActual, String tipoMercancia) {
        this.numVagon = numVagon;
        this.cargaMaxima = cargaMaxima;
        this.cargaActual = cargaActual;
        this.tipoMercancia = tipoMercancia;
    }
}
