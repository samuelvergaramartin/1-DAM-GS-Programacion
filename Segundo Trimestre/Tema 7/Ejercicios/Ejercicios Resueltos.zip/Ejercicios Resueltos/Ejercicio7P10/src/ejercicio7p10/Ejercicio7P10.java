package ejercicio7p10;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Ejercicio7P10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
