package ejercicio7p14;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Ejercicio7P14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Main main = new Main();
        main.insertarFinal(11);
    }
    
}
