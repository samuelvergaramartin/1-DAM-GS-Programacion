package ejercicio7p14aplicacion;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Ejercicio7P14Aplicacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cambio cambio = new Cambio();
        cambio.mostrarCambio(100);
    }
    
}
