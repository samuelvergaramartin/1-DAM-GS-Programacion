package ejercicioanexoenumerados;

/**
 *
 * @author Samuel Vergara Martín
 */
public enum billetes {
    Cinco, Diez, Veinte, Cincuenta, Cien, Doscientos
}
