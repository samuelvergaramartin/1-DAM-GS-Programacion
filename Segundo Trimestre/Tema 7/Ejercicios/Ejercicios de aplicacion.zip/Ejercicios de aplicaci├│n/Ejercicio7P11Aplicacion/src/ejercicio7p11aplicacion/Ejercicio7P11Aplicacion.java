package ejercicio7p11aplicacion;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Ejercicio7P11Aplicacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MarcaPagina pagina = new MarcaPagina();
        pagina.start();
    }
    
}
