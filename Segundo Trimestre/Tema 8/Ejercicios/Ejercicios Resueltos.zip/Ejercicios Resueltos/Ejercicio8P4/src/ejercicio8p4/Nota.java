package ejercicio8p4;

/**
 *
 * @author Samuel Vergara Martín
 */
public enum Nota {DO, RE, MI, FA, SOL, LA, SI}
