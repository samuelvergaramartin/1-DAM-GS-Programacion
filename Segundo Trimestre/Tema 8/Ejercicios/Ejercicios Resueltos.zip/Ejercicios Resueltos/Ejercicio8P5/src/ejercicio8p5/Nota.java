package ejercicio8p5;

/**
 *
 * @author Samuel Vergara Martín
 */
public enum Nota {DO, RE, MI, FA, SOL, LA, SI}
