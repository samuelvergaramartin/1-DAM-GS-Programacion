package movilidad;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Movilidad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
