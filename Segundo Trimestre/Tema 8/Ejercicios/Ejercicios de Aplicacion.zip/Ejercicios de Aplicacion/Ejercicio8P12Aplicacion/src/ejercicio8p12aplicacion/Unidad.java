package ejercicio8p12aplicacion;

/**
 *
 * @author Samuel Vergara Martín
 */
public enum Unidad {cm, m, m3}
