package ejercicio8p14aplicacion;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Ejercicio8P14Aplicacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
