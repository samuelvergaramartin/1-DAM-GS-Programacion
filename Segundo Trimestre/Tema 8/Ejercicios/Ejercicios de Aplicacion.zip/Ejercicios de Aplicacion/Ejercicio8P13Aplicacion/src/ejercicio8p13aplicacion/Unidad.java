package ejercicio8p13aplicacion;

/**
 *
 * @author Samuel Vergara Martín
 */
public enum Unidad {cm, m, m3}
