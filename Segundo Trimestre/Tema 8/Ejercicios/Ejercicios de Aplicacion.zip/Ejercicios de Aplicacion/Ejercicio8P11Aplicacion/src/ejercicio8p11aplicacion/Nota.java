package ejercicio8p11aplicacion;

/**
 *
 * @author Samuel Vergara Martín
 */
public enum Nota {DO, RE, MI, FA, SOL, LA, SI}
