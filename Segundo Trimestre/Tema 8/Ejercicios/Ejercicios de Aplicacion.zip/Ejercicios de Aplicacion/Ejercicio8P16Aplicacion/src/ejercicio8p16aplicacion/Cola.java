package ejercicio8p16aplicacion;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Cola extends Lista{
    Cola() {
        super();
    }
}
