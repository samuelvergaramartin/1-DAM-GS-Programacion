package ejercicio8p16aplicacion;
import static netcat_utils.Colors.CYAN;
/**
 *
 * @author Samuel Vergara Martín
 */
public class Ejercicio8P16Aplicacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
