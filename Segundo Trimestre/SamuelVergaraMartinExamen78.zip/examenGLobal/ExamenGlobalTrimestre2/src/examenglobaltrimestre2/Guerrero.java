package examenglobaltrimestre2;

/**
 *
 * @author Samuel Vergara Martín
 */
public class Guerrero extends Personaje{
    Guerrero(int codigo) {
        super(15, codigo);
    }
    
    @Override
    public int getVida() {
        return super.getVida();
    }
    
    @Override
    public void setVida(int vida) {
        super.setVida(vida);
    }
    
    @Override
    public String toString() {
        return super.toString();
    }
}
