/**
 * @author Samuel Vergara Martín
 */
public class Actividad6P7 {
    
}
